﻿using System.Data.Entity;

namespace InterAssessment.Models
{

    public class AppDbContext : DbContext
    {
        public AppDbContext()
        {
        }

        public DbSet<Persons> Persons { get; set; }
        public DbSet<Accounts> Account { get; set; }
        public DbSet<Transactions> Transactions { get; set; }
    }

}