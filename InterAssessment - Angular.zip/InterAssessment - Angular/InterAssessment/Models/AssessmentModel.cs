﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace InterAssessment.Models
{
    public class Accounts
    {
        [Required]
        
        [Key]
        public int code { get; set; }


        [Required]
        public string person_code { get; set; }

        [Required]
        [DataType(DataType.Text)]
        public string account_number { get; set; }


        [Required]
        public long outstanding_balance { get; set; }


    }

    public class Persons
    {
        [Required]
        [Key]
        public int code { get; set; }


        [Required]
        public string name { get; set; }

        [Required]
        [DataType(DataType.Text)]
        public string surname { get; set; }


        [Required]
        public string id_number { get; set; }


    }

    public class Transactions
    {
        [Required]
        [Key]
        public int code { get; set; }


        [Required]
        public int account_code { get; set; }

        [Required]
        
        public DateTime  transaction_date{ get; set; }

        [Required]

        public DateTime capture_date { get; set; }


        [Required]
        public string description{ get; set; }


    }
}