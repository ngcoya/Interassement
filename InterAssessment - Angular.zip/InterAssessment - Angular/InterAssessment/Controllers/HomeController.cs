﻿using System;
using System.Linq;
using System.Web.Mvc;
using InterAssessment.Models;
using System.Web.Http;
using InterAssessment.Models;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Net;
using System.Net.Http;
using System.Web.Http.Description;
using Newtonsoft.Json.Serialization;

namespace InterAssessment.Controllers
{
    [System.Web.Http.RoutePrefix("Api/Persons")]
    public class PersonsAPIController : Controller
    {
         AppDbContext objEntity = new AppDbContext();

        [System.Web.Http.HttpGet]
        [System.Web.Http.Route("AllPersons")]
        public IQueryable<Persons> GetEmaployee()
        {
            try
            {
                return objEntity.Persons;
            }
            catch (Exception)
            {
                throw;
            }
        }
        
        [System.Web.Http.HttpGet]

        [System.Web.Http.Route("GetPersonsDetailsById/{PersonsId}")]
        public IHttpActionResult GetEmaployeeById(string Persons)
        {
            AppDbContext objPers = new AppDbContext();

            int ID = Convert.ToInt32(Persons);
            try
            {
                objPers = objEntity.Persons(ID);
                if (objPers == null)
                {
                    return NotFound();
                }
            }
            catch (Exception)
            {
                throw;
            }
            return Ok(objPers);
        }

        [System.Web.Http.HttpPost]
        [System.Web.Http.Route("InsertPersonDetails")]
        public IHttpActionResult PostPersons(Persons data)
        {

            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }
            try
            {
                objEntity.EmployeeDetails.Add(data);
                objEntity.SaveChanges();
            }
            catch (Exception)
            {
                throw;
            }

            return Ok(data);
        }

        [System.Web.Http.HttpPut]
        [System.Web.Http.Route("UpdatePersonsDetails")]
        public IHttpActionResult PutEmaployeeMaster(Persons persons)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            try
            {
                AppDbContext objPersons = new AppDbContext();
                
                objPersons = objEntity.Persons.Find(persons.id_number);

                if (objEmp != null)
                {
                    objPersons.Persons = persons.id_number();
                    objPersons.EmpName = employee.EmpName;
                    objPersons.Address = employee.Address;
                    objPersons.EmailId = employee.EmailId;
                    objPersons.DateOfBirth = employee.DateOfBirth;
                    objPersons.Gender = employee.Gender;
                    objPersons.PinCode = employee.PinCode;
                }
                int i = this.objEntity.SaveChanges();
            }
            catch (Exception)
            {
                throw;
            }
            return Ok(persons);
        }

        [System.Web.Http.HttpDelete]
        [System.Web.Http.Route("DeletePersonsDetails")]
        public IHttpActionResult DeletePersonsDelete(int id)
        {
            //int empId = Convert.ToInt32(id);  
            AppDbContext Persons = objEntity.EmployeeDetails.Find(id);
            if (Persons == null)
            {
                return NotFound();
            }

            objEntity.PersonDetails.Remove(Persons);
            objEntity.SaveChanges();

            return Ok(Persons);
        }
    }
}