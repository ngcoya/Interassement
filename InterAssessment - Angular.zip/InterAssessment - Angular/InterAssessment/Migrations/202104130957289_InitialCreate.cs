﻿namespace InterAssessment.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class InitialCreate : DbMigration
    {
        public override void Up()
        {
            CreateTable(
                "dbo.AccountsModels",
                c => new
                    {
                        code = c.Int(nullable: false, identity: true),
                        person_code = c.String(nullable: false),
                        account_number = c.String(nullable: false),
                        outstanding_balance = c.Long(nullable: false),
                    })
                .PrimaryKey(t => t.code);
            
            CreateTable(
                "dbo.PersonsModels",
                c => new
                    {
                        code = c.Int(nullable: false, identity: true),
                        name = c.String(nullable: false),
                        surname = c.String(nullable: false),
                        id_number = c.String(nullable: false),
                    })
                .PrimaryKey(t => t.code);
            
            CreateTable(
                "dbo.TransactionsModels",
                c => new
                    {
                        code = c.Int(nullable: false, identity: true),
                        account_code = c.Int(nullable: false),
                        transaction_date = c.DateTime(nullable: false),
                        capture_date = c.DateTime(nullable: false),
                        description = c.String(nullable: false),
                    })
                .PrimaryKey(t => t.code);
            
        }
        
        public override void Down()
        {
            DropTable("dbo.TransactionsModels");
            DropTable("dbo.PersonsModels");
            DropTable("dbo.AccountsModels");
        }
    }
}
