import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Persons } from './Persons';


@Injectable({
  providedIn: 'root'
})
export class PersonsService {
  url = 'http://localhost:65389/Api/Persons';
  constructor(private http: HttpClient) { }
  getAllPersons(): Observable<Persons[]> {
    return this.http.get<Persons[]>(this.url + '/AllPersonsDetails');
  }

  getPersonsById(PersonsId: string): Observable<Persons> {
    return this.http.get<Persons>(this.url + '/GetPersonsDetailsById/' + PersonsId);
  }
  createPersons(Persons: Persons): Observable<Persons> {
    const httpOptions = { headers: new HttpHeaders({ 'Content-Type': 'application/json' }) };
    return this.http.post<Persons>(this.url + '/InsertPersonsDetails/', Persons, httpOptions);
  }

  updatePersons(Persons: Persons): Observable<Persons> {
    const httpOptions = { headers: new HttpHeaders({ 'Content-Type': 'application/json' }) };
    return this.http.put<Persons>(this.url + '/UpdatePersonsDetails/', Persons, httpOptions);
  }

  deletePersonsById(Personsid: string): Observable<number> {
    const httpOptions = { headers: new HttpHeaders({ 'Content-Type': 'application/json' }) };
    return this.http.delete<number>(this.url + '/DeletePersonsDetails?id=' + Personsid, httpOptions);
  }

}
