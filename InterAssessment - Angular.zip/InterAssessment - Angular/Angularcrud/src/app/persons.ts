export class Persons 
{
    IDNumber: number;
    Surname: string;
    AccountNumber: number;
}
