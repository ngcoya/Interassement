import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { Observable } from 'rxjs';
import { PersonsService } from '../Persons.service';
import { Persons } from '../Persons';

@Component({
  selector: 'app-Persons',
  templateUrl: './Persons.component.html',
  styleUrls: ['./Persons.component.css']
})
export class PersonsComponent implements OnInit {
  dataSaved = false;
  PersonsForm: any;
  allPersonss: Observable<Persons[]>;
  PersonsIdUpdate = null;
  massage = null;

  constructor(private formbulider: FormBuilder, private PersonsService: PersonsService) { }

  ngOnInit() {
    this.PersonsForm = this.formbulider.group({
      IDNumber: ['', [Validators.required]],
      Surname: ['', [Validators.required]],
      AccountNumber: ['', [Validators.required]],
     
    });
    this.loadAllPersonss();
  }
  loadAllPersonss() {
    this.allPersonss = this.PersonsService.getAllPersons();
  }

  onFormSubmit() {
    this.dataSaved = false;
    const Persons = this.PersonsForm.value;
    this.CreatePersons(Persons);
    this.PersonsForm.reset();
  }
  loadPersonsToEdit(PersonsId: string) {
    this.PersonsService.getPersonsById(PersonsId).subscribe(Persons => {
      this.massage = null;
      this.dataSaved = false;
      this.PersonsIdUpdate = Persons.IDNumber;
      this.PersonsForm.controls['ID Number'].setValue(Persons.IDNumber);
      this.PersonsForm.controls['Surname'].setValue(Persons.Surname);
      this.PersonsForm.controls['Account Number'].setValue(Persons.AccountNumber);
    });

  }
  CreatePersons(Persons: Persons) {
    if (this.PersonsIdUpdate == null) {
      this.PersonsService.createPersons(Persons).subscribe(
        () => {
          this.dataSaved = true;
          this.massage = 'Record saved Successfully';
          this.loadAllPersonss();
          this.PersonsIdUpdate = null;
          this.PersonsForm.reset();
        }
      );
    } else {
      Persons.IDNumber = this.PersonsIdUpdate;
      this.PersonsService.updatePersons(Persons).subscribe(() => {
        this.dataSaved = true;
        this.massage = 'Record Updated Successfully';
        this.loadAllPersonss();
        this.PersonsIdUpdate = null;
        this.PersonsForm.reset();
      });
    }
  }
 
  deletePersons(PersonsId: string) {
    if (confirm("Are you sure you want to delete this ?")) {  
    this.PersonsService.deletePersonsById(PersonsId).subscribe(() => {
      this.dataSaved = true;
      this.massage = 'Record Deleted Succefully';
      this.loadAllPersonss();
      this.PersonsIdUpdate = null;
      this.PersonsForm.reset();

    });
  }
}
  resetForm() {
    this.PersonsForm.reset();
    this.massage = null;
    this.dataSaved = false;
  }
}
